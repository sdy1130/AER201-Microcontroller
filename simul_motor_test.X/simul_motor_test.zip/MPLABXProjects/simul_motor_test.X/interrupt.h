#ifndef INTERRUPT_H
#define	INTERRUPT_TEMPLATE_H

//void set_external_interrupt0(int time);
void set_external_interrupt1(int time);
void set_external_interrupt3(int time);
//void servo_ISR_0();
void servo_ISR_1();
void servo_ISR_3();

#endif