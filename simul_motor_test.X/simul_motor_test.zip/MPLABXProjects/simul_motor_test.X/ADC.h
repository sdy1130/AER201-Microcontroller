#ifndef ADC_H
#define	ADC_H

float readADC(char channel);

#endif	/* ADC_H */